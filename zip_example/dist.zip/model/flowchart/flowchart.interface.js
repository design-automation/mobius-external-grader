"use strict";
//
//
// The flowchart is the basic datastructure in Mobius - it is essentially a linked-list.
// It also
//
Object.defineProperty(exports, "__esModule", { value: true });
exports.canvasSize = 10000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmxvd2NoYXJ0LmludGVyZmFjZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9tb2RlbC9mbG93Y2hhcnQvZmxvd2NoYXJ0LmludGVyZmFjZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsRUFBRTtBQUNGLEVBQUU7QUFDRix3RkFBd0Y7QUFDeEYsVUFBVTtBQUNWLEVBQUU7O0FBMEJXLFFBQUEsVUFBVSxHQUFHLEtBQUssQ0FBQyJ9