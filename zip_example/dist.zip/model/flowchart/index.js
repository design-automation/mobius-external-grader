"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var flowchart_interface_1 = require("./flowchart.interface");
exports.canvasSize = flowchart_interface_1.canvasSize;
var flowchart_utils_1 = require("./flowchart.utils");
exports.FlowchartUtils = flowchart_utils_1.FlowchartUtils;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvbW9kZWwvZmxvd2NoYXJ0L2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsNkRBQStEO0FBQTFDLDJDQUFBLFVBQVUsQ0FBQTtBQUMvQixxREFBbUQ7QUFBMUMsMkNBQUEsY0FBYyxDQUFBIn0=