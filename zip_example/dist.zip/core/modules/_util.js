"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function approx(n1, n2, t) {
    return Math.abs(n1 - n2) < t;
}
exports.approx = approx;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX3V0aWwuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvY29yZS9tb2R1bGVzL191dGlsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsU0FBZ0IsTUFBTSxDQUFDLEVBQVUsRUFBRSxFQUFVLEVBQUUsQ0FBUztJQUNwRCxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNqQyxDQUFDO0FBRkQsd0JBRUMifQ==