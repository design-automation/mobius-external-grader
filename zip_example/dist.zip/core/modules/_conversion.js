"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function radToDeg(rad) {
    return rad * (180 / Math.PI);
}
exports.radToDeg = radToDeg;
function degToRad(deg) {
    return deg * (Math.PI / 180);
}
exports.degToRad = degToRad;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX2NvbnZlcnNpb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvY29yZS9tb2R1bGVzL19jb252ZXJzaW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsU0FBZ0IsUUFBUSxDQUFDLEdBQVc7SUFDaEMsT0FBTyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2pDLENBQUM7QUFGRCw0QkFFQztBQUNELFNBQWdCLFFBQVEsQ0FBQyxHQUFXO0lBQ2hDLE9BQU8sR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQztBQUNqQyxDQUFDO0FBRkQsNEJBRUMifQ==