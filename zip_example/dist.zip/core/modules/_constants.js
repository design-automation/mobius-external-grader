"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("../../libs/geo-info/common");
exports.XY = common_1.XYPLANE;
exports.YZ = common_1.YZPLANE;
exports.ZX = common_1.ZXPLANE;
exports.YX = common_1.YXPLANE;
exports.ZY = common_1.ZYPLANE;
exports.XZ = common_1.XZPLANE;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX2NvbnN0YW50cy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9jb3JlL21vZHVsZXMvX2NvbnN0YW50cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHVEQUFpRztBQUVwRixRQUFBLEVBQUUsR0FBRyxnQkFBTyxDQUFDO0FBQ2IsUUFBQSxFQUFFLEdBQUcsZ0JBQU8sQ0FBQztBQUNiLFFBQUEsRUFBRSxHQUFHLGdCQUFPLENBQUM7QUFFYixRQUFBLEVBQUUsR0FBRyxnQkFBTyxDQUFDO0FBQ2IsUUFBQSxFQUFFLEdBQUcsZ0JBQU8sQ0FBQztBQUNiLFFBQUEsRUFBRSxHQUFHLGdCQUFPLENBQUMifQ==